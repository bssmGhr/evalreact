const recipes = [
    { id: 1, title: 'Pizza Margherita', description: 'Une pizza classique italienne.' },
    { id: 2, title: 'Tarte aux pommes', description: 'Un dessert délicieux avec des pommes.' },
    { id: 3, title: 'Spaghetti Carbonara', description: 'Un plat de pâtes crémeux avec du bacon.' },
  ];
  
  export default recipes;